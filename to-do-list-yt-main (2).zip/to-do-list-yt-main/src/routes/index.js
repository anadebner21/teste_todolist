import { Router } from "express";
import { TaskController } from "../controllers/TaskController.js";

const routes = Router();
const task = new TaskController();

routes.post("/task", async (req, res) => {
    const { titulo, descricao, data_criacao, data_prev_execucao, status } = req.body;
    const newTask = await task.createTask({titulo, descricao, data_criacao, data_prev_execucao, status })
    res.status(201).send(newTask);
})

/* routes.get("/task/:id", async (req, res) => {
    const { id } = req.params;
    const taskId = await task.createTask(id);
    if (taskId[0] === undefined) {
        res.status(400).json('Tarefa não existe')
    }
    res.status(200).json(taskId);
}) */

/* routes.put("/taskController/:id", async (req, res) => {
    const { id } = req.params;
    const { titulo, descricao, data_criacao, data_prev_execucao, status } = req.body;
    const updateTask = task.({ id, titulo, descricao, data_criacao, data_prev_execucao, status });
    if (!updateTask) {
        res.status(404).json("Error");
    } else {
        res.status(200).json("Success!");
    }
}) */

routes.get("/task/:id", async (req, res)=>{
    const {id} = req.params;
    const taskId = await task.listTaskById(id);
    if (taskId[0] === undefined) {
        res.status(400).json('tarefa não existe')
    }
    res.status(200).send(taskId);
})

routes.delete("/taskController/:id", async (req, res) => {
    const { id } = req.params;
    const deletTaskById = await task.deleteById(id);
    if (!deletTaskById) {
        res.status(400).json("Este task não existe");
    } else {
        res.status(204).json("Task deletado com sucesso");
    }
})
routes.patch("/task/:id/done", async (req, res) =>{
    const {id} = req.params;
    const status = true;
    await task.updateTaskStatus({id, status})
    res.status(201).json("Tarefa concluída")
})
export { routes }