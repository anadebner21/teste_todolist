import { pool } from "../database/index.js";


class TaskController{
    async createTask({titulo, descricao, data_criacao, data_prev_execucao, status}){
        const [result] = await pool.query(`INSERT INTO tarefa (titulo, descricao, data_criacao, data_prev_execucao, status) VALUES (?, ?, ?, ?, ?)`, [titulo, descricao, data_criacao, data_prev_execucao, status])
        const id = result.insertId;
        return this.listAllTask();
    
    }
    async listAllTask(){
        const [row] = await pool.query(`SELECT * FROM tarefa`)
        return row;
    }
    async listTaskById(id){
        const [rows] = await pool.query(`SELECT * FROM tarefa WHERE id = ${id}`)
        return rows[0];
    }
    async deleteById(id){
        const [rows] = await pool.query(`DELETE FROM tarefa WHERE id = ${id}`)
        return rows[0];
    }

    async updateTaskStatus(id, status){
        const [rows] = await pool.query (`UPDATE tarefa SET status = ? WHERE id = ${id}`, [status, id]);
        return rows; 
    }
    
}

export {TaskController}