class Task {
    constructor(){
        this.id
        this.titulo
        this.descricao
        this.data_criacao
        this.data_prev_execucao
        this.status=false
    }
}