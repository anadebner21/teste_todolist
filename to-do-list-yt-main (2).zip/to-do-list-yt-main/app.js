import express from 'express'
import path from 'path'
 
//import { routes } from './routes'
//import { homeRoutes } from './routes/home.routes'

//import './database/sequelize'
//import { middlewareGlobal } from './middlewares/middleware'

const app = express()

app.use(express.urlencoded({ extended: true }))
app.use(express.json())

/* app.use(express.static(path.resolve(__dirname, 'public')))
 */
//app.use(routes)
//app.use(homeRoutes)

app.set('views', './src/views')
app.set('view engine', 'ejs')

app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).send('Algo deu errado')
})

export { app }
